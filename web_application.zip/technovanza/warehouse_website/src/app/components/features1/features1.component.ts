import { Component, Input } from '@angular/core'

@Component({
  selector: 'app-features1',
  templateUrl: 'features1.component.html',
  styleUrls: ['features1.component.css'],
})
export class Features1 {
  @Input()
  feature1ImgAlt: string = 'Barcode scanning for parameter determination'
  @Input()
  feature3Description: string = 'Classification of warehouse positions'
  @Input()
  feature3Title: string = 'Warehouse Position Classification'
  @Input()
  feature3ImgSrc: string =
    'https://images.unsplash.com/photo-1503551723145-6c040742065b-v2?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w5MTMyMXwwfDF8cmFuZG9tfHx8fHx8fHx8MTczNDg1MDYzNXw&ixlib=rb-4.0.3&q=80&w=1080'
  @Input()
  feature1ImgSrc: string =
    'https://images.unsplash.com/photo-1516062423079-7ca13cdc7f5a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w5MTMyMXwwfDF8cmFuZG9tfHx8fHx8fHx8MTczNDg1MDYzNXw&ixlib=rb-4.0.3&q=80&w=1080'
  @Input()
  feature2Description: string = 'Detailed parameter analysis'
  @Input()
  feature1Title: string = 'Barcode Parameter Determination'
  @Input()
  feature3ImgAlt: string = 'Warehouse position classification image'
  @Input()
  feature1Description: string = 'Scan barcodes to determine parameters'
  @Input()
  feature2ImgSrc: string =
    'https://images.unsplash.com/photo-1600439614353-174ad0ee3b25?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w5MTMyMXwwfDF8cmFuZG9tfHx8fHx8fHx8MTczNDg1MDYzNnw&ixlib=rb-4.0.3&q=80&w=1080'
  @Input()
  feature2ImgAlt: string = 'Detailed parameter analysis image'
  @Input()
  feature2Title: string = 'Parameter Analysis'
  activeTab: number = 0
  constructor() {}
}
