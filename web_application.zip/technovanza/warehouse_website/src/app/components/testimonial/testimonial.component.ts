import { Component, Input } from '@angular/core'

@Component({
  selector: 'app-testimonial',
  templateUrl: 'testimonial.component.html',
  styleUrls: ['testimonial.component.css'],
})
export class Testimonial {
  @Input()
  author2Position: string = 'Logistics Coordinator'
  @Input()
  author1Position: string = 'Warehouse Manager'
  @Input()
  author3Alt: string = 'MJ'
  @Input()
  author1Name: string = 'John Doe'
  @Input()
  author1Src: string =
    'https://images.unsplash.com/photo-1728887823143-d92d2ebbb53a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w5MTMyMXwwfDF8cmFuZG9tfHx8fHx8fHx8MTczNDg1MDYzNHw&ixlib=rb-4.0.3&q=80&w=1080'
  @Input()
  author3Name: string = 'Michael Johnson'
  @Input()
  review2: string =
    "The barcode system is a game-changer for us. It's so easy to locate items now!"
  @Input()
  author2Name: string = 'Jane Smith'
  @Input()
  author4Position: string = 'Shipping Supervisor'
  @Input()
  author4Name: string = 'Sarah Williams'
  @Input()
  author4Src: string =
    'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w5MTMyMXwwfDF8cmFuZG9tfHx8fHx8fHx8MTczNDg1MDYzNXw&ixlib=rb-4.0.3&q=80&w=1080'
  @Input()
  author1Alt: string = 'JD'
  @Input()
  author2Src: string =
    'https://images.unsplash.com/photo-1440589473619-3cde28941638?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w5MTMyMXwwfDF8cmFuZG9tfHx8fHx8fHx8MTczNDg1MDYzNXw&ixlib=rb-4.0.3&q=80&w=1080'
  @Input()
  author3Src: string =
    'https://images.unsplash.com/photo-1484588168347-9d835bb09939?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w5MTMyMXwwfDF8cmFuZG9tfHx8fHx8fHx8MTczNDg1MDYzNXw&ixlib=rb-4.0.3&q=80&w=1080'
  @Input()
  author2Alt: string = 'JS'
  @Input()
  author4Alt: string = 'SW'
  @Input()
  content1: string =
    'This system has greatly improved our warehouse organization and efficiency. Highly recommended!'
  @Input()
  author3Position: string = 'Inventory Specialist'
  @Input()
  review1: string = '5 stars'
  @Input()
  heading1: string = 'Testimonials'
  @Input()
  review3: string =
    "I can't imagine managing inventory without this tool. It's a lifesaver!"
  @Input()
  review4: string =
    'The daily purchase quantity feature has helped us plan our orders more effectively. Great system!'
  constructor() {}
}
