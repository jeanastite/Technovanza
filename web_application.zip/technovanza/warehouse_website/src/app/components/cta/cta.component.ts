import { Component, Input } from '@angular/core'

@Component({
  selector: 'app-cta',
  templateUrl: 'cta.component.html',
  styleUrls: ['cta.component.css'],
})
export class CTA {
  @Input()
  heading1: string = 'Determine Warehouse Position'
  @Input()
  content1: string =
    'Use the parameters provided through barcodes to determine the position of the boxes in the warehouse.'
  @Input()
  action1: string = 'Get Started'
  constructor() {}
}
