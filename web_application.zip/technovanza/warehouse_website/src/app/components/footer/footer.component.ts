import { Component, Input } from '@angular/core'

@Component({
  selector: 'app-footer',
  templateUrl: 'footer.component.html',
  styleUrls: ['footer.component.css'],
})
export class Footer {
  @Input()
  column2Title: string = 'Quick Links'
  @Input()
  link7: string = 'Cookie Policy'
  @Input()
  link5: string = 'Terms and Conditions'
  @Input()
  link8: string = 'Accessibility'
  @Input()
  action1: string = 'Subscribe to Newsletter'
  @Input()
  content3: string = 'Designed by YourCompany'
  @Input()
  link4: string = 'FAQs'
  @Input()
  logoSrc: string =
    'https://presentation-website-assets.teleporthq.io/logos/logo.png'
  @Input()
  cookiesLink: string = '/cookie-policy'
  @Input()
  content2: string = '© 2022 Warehouse Management System. All Rights Reserved.'
  @Input()
  link9: string = 'Blog'
  @Input()
  link6: string = 'Privacy Policy'
  @Input()
  logoAlt: string = 'Warehouse Management System Logo'
  @Input()
  link1: string = 'Home'
  @Input()
  privacyLink: string = '/privacy-policy'
  @Input()
  link10: string = 'Support'
  @Input()
  column1Title: string = 'Contact Us'
  @Input()
  termsLink: string = '/terms-and-conditions'
  @Input()
  link3: string = 'Services'
  @Input()
  link2: string = 'About Us'
  @Input()
  socialLinkTitleCategory: string = 'Follow Us'
  constructor() {}
}
