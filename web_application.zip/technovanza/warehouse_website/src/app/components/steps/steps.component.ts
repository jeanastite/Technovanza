import { Component, Input } from '@angular/core'

@Component({
  selector: 'app-steps',
  templateUrl: 'steps.component.html',
  styleUrls: ['steps.component.css'],
})
export class Steps {
  @Input()
  step1Description: string =
    'Scan the barcode of the box to retrieve its parameters.'
  @Input()
  step3Description: string =
    'Assign the box to one of the three categories in the warehouse: Easily accessible, Moderately accessible, or Hardly accessible.'
  @Input()
  step2Title: string = 'Determine Parameters'
  @Input()
  step2Description: string =
    'Based on the parameters such as demand score, expiry date, size, and daily purchase quantity, determine the position of the box in the warehouse.'
  @Input()
  step1Title: string = 'Scan Barcode'
  @Input()
  step3Title: string = 'Assign Position'
  @Input()
  step4Description: string =
    'Save the assigned position of the box in the warehouse for future reference.'
  @Input()
  step4Title: string = 'Save Position'
  constructor() {}
}
